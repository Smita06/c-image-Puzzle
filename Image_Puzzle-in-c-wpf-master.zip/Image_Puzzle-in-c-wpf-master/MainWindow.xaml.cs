﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Diagnostics;
using System.Windows.Threading;
using System.Collections;


namespace Projectf
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		
		private int time = 0;
		//create timer object instance
		DispatcherTimer dtclockTime = new DispatcherTimer();
		//array to store the images
		List<BitmapImage> _images = new List<BitmapImage>();
		//array of button
		System.Windows.Controls.Button[] buttons;
		//array of pictures
		string[] pictures;
		//initiliaze the counter
		int count = 0;
		//array to store images
		ArrayList images = new ArrayList();
		//array of pictures
		string[] photo;

		public MainWindow()
		{
			InitializeComponent();
			//initialize the array of buttons
			buttons = new System.Windows.Controls.Button[] { b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16 };
			//initialize the array of filename
			pictures = new string[] { @"C:\Users\User\Desktop\nscproject\Picture_1\3.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\2.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\1.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\6.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\5.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\4.jpg",@"C:\Users\User\Desktop\nscproject\Picture_1\7.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\10.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\9.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\8.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\13.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\12.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\11.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\14.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\15.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\16.jpg" };
            //initialize the array of filename
			photo = new string[] { @"C:\Users\User\Desktop\nscproject\Picture_1\1.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\2.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\3.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\4.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\5.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\6.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\7.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\8.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\9.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\10.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\11.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\12.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\13.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\14.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\15.jpg", @"C:\Users\User\Desktop\nscproject\Picture_1\16.jpg" };

		}

		private void Button_1_Click(object sender, RoutedEventArgs e)
		{
			//Create OpenFileDialog
			Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

			//Display OpenFileDialog by calling ShowDialog method
			Nullable<bool> result = dlg.ShowDialog();

			//Get the selected file name and write it on the textbox
			if (result == true)
			{
				text_Box1.Text = dlg.FileName;

				// Open document 
				string filename = dlg.FileName;
				text_Box1.Text = filename;

				//create source
				BitmapImage myBitmapImage = new BitmapImage();
				myBitmapImage.BeginInit();
				myBitmapImage.UriSource = new Uri(dlg.FileName);
				myBitmapImage.EndInit();

				//set image source
				Image_1.Source = myBitmapImage;

			}
			//add images to button
			for (int i = 0; i <= 15; i++)
			{
				AddImagesToButtons(_images);
				buttons[i].Background = new ImageBrush(_images[i]);
			}
		}
		//Function to close the program
		private void Button_Quit_Click(object sender, RoutedEventArgs e)
		{
			checkwin();
			this.Close();
		}

		private void Start_Button_Click(object sender, RoutedEventArgs e)
		{
			dtclockTime.Interval = new TimeSpan(0, 0, 1);
			dtclockTime.Tick += DtclockTime_Tick;
			//start the timer
			dtclockTime.Start();
		}

		//stopwatch timer event handler
		private void DtclockTime_Tick(object sender, EventArgs e)
		{
			if (time >= 0)
			{
				time++;
				Timer.Text = string.Format("00:0{0}:{1}", time / 60, time % 60);
			}
			else
			{
				dtclockTime.Stop();
			}
		}
		// generate the array of images

		private void AddImagesToButtons(List<BitmapImage> images)
		{
			for(int i=0;i<=15;i++)
			{
				BitmapImage bImage = new BitmapImage(new Uri(pictures[i]));
				_images.Add(bImage);
			}
		}
		
		//code for pause button
		private void Pause_Button_Click(object sender, RoutedEventArgs e)
		{
			if ((string)Pause_Button.Content == "Pause")
			{
				dtclockTime.Stop();
				Pause_Button.Content = "Resume";
			}
			else
			{
				dtclockTime.Start();
				Pause_Button.Content = "Pause";
			}
		}

		//code to shuffle the images

		private void shuffle_Click(object sender, RoutedEventArgs e)
		{
			shufffle(_images);
			for (int i = 0; i <= 15; i++)
			{
				AddImagesToButtons(_images);
				buttons[i].Background = new ImageBrush(_images[i]);
			}
		}

		private void shufffle(List<BitmapImage> images)
		{
			Random rng = new Random();
			BitmapImage tmp;
			for (int i = images.Count-1; i > 1; i--)
			{
				// Pick a random element to swap with the i-th element.
				int j = rng.Next(i-1);  // 0 <= j <= i-1 (0-based array)
				tmp = images[j];
				images.RemoveAt(j);
			}
		}
	
		// To move the button images
		private void b1_Click(object sender, RoutedEventArgs e)
		{
			count++;
			textbox1.Text =Convert.ToString( count) ;
			var btn = (System.Windows.Controls.Button)sender;

			switch (btn.Name)
			{
				case "b1":
					System.Windows.Media.Brush Temp = b1.Background;
					b1.Background = b2.Background;
					b2.Background = Temp;
					break;
				case "b2":
					System.Windows.Media.Brush Temp1 = b2.Background;
					b2.Background = b3.Background;
					b3.Background = Temp1;
					break;
				case "b3":
					System.Windows.Media.Brush Temp2 = b3.Background;
					b3.Background = b4.Background;
					b4.Background = Temp2;
					break;
				case "b4":
					System.Windows.Media.Brush Temp3 = b4.Background;
					b4.Background = b8.Background;
					b8.Background = Temp3;
					break;
				case "b8":
					System.Windows.Media.Brush Temp4 = b8.Background;
					b8.Background = b7.Background;
					b7.Background = Temp4;
					break;
				case "b7":
					System.Windows.Media.Brush Temp5 = b7.Background;
					b7.Background = b6.Background;
					b6.Background = Temp5;
					break;
				case "b6":
					System.Windows.Media.Brush Temp6 = b6.Background;
					b6.Background = b5.Background;
					b5.Background = Temp6;
					break;
				case "b5":
					System.Windows.Media.Brush Temp7 = b5.Background;
					b5.Background = b9.Background;
					b9.Background = Temp7;
					break;
				case "b9":
					System.Windows.Media.Brush Temp8 = b9.Background;
					b9.Background = b10.Background;
					b10.Background = Temp8;
					break;
				case "b10":
					System.Windows.Media.Brush Temp9 = b10.Background;
					b10.Background = b11.Background;
					b11.Background = Temp9;
					break;
				case "b11":
					System.Windows.Media.Brush Temp10 = b11.Background;
					b11.Background = b12.Background;
					b12.Background = Temp10;
					break;
				case "b12":
					System.Windows.Media.Brush Temp11 = b12.Background;
					b12.Background = b16.Background;
					b16.Background = Temp11;
					break;
				case "b16":
					System.Windows.Media.Brush Temp12 = b16.Background;
					b16.Background = b15.Background;
					b15.Background = Temp12;
					break;
				case "b15":
					System.Windows.Media.Brush Temp13 = b15.Background;
					b15.Background = b14.Background;
					b14.Background = Temp13;
					break;
				case "b14":
					System.Windows.Media.Brush Temp14 = b14.Background;
					b14.Background = b13.Background;
					b13.Background = Temp14;
					break;
				case "b13":
					System.Windows.Media.Brush Temp15 = b13.Background;
					b13.Background = b9.Background;
					b9.Background = Temp15;
					break;

			}
		}

		//code to check the result 
		private void checkwin()
		{
			if(count>=20 && count <=35 && time <=30)
			{
				compareTo();
				System.Windows.MessageBox.Show("EXCELLENT");
				System.Windows.MessageBox.Show("Your Score: 100");
				
			}
			else if(count >25 && count <=35 && time >30 && time <=50)
			{
				compareTo();
				System.Windows.MessageBox.Show("VERY GOOD");
				System.Windows.MessageBox.Show("Your Score:80");
			}
			else if(count >35 && count<=55 && time >50 && time <=70)
			{
				compareTo();
				System.Windows.MessageBox.Show("GOOD");
				System.Windows.MessageBox.Show("Your Score:70");
			}
			else if(count >55 && count <=75 && time >70 && time <=100)
			{
				System.Windows.MessageBox.Show("AVERAGE");
				System.Windows.MessageBox.Show("Your Score:60");
			}
			else if(count >75 && count <=95 && time >100 && time <=130)
			{
				System.Windows.MessageBox.Show("BELOW AVERAGE");
				System.Windows.MessageBox.Show("Your Score:45");
			}
			else if(count>95 && time >130)
			{
				System.Windows.MessageBox.Show("POOR");
				System.Windows.MessageBox.Show("Your Score:35");
			}
			else
			{
				System.Windows.MessageBox.Show("PLAY AGAIN!");
			}
		}

		//code to compare the Images
		private void compareTo()
		{
			AddImages(images);
			for(int i=0;i<=15;i++)
			{
				if (buttons[i].Background == images[i])
				{ }	
			}
			System.Windows.MessageBox.Show("Congratulations You Won!");
}

		//code to add the images to array
		private void AddImages(ArrayList images)
		{
			for (int i = 0; i <= 15; i++)
			{
				BitmapImage bImage = new BitmapImage(new Uri(photo[i]));
				images.Add(bImage);
			}
		}
	}
	}
	
